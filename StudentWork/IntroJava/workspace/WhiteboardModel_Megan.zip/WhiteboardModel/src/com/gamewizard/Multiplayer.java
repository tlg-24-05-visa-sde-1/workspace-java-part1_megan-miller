package com.gamewizard;

public enum Multiplayer {
    ONE,
    TWO,
    THREE,
    FOUR;
}
